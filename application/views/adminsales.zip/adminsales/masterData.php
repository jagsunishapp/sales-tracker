<?php

include "include/header.php";
?>

    <div id="sidebarMenu" class="sidebar sidebar-fixed sidebar-components">
      <div class="sidebar-header">
        <a href="" id="mainMenuOpen"><i data-feather="menu"></i></a>
        <h5>Components</h5>
        <a href="" id="sidebarMenuClose"><i data-feather="x"></i></a>
      </div><!-- sidebar-header -->
      <div class="sidebar-body">
        <ul class="sidebar-nav">
         <li class="nav-label mg-b-15">Master</li>
         <li class="nav-item"><a href="#" id="btn1"> Purpose</a></li>

		<li class="nav-item"><a href="#" id="btn2"> Expense Categories</a></li>
		<li class="nav-item"><a href="#" id="btn3"> Territory Categories</a></li>
		<li class="nav-item"><a href="#" id="btn4"> Industry Categories</a></li>
		<li class="nav-item"><a href="#" id="btn5"> List Categories</a></li>
		<li class="nav-item"><a href="#" id="btn6"> office Location</a></li>
		
         
	
          
         
         
        </ul>
      </div><!-- sidebar-body -->
    </div><!-- sidebar -->

    <div class="content content-components">
   
   

 
        <div class="row tx-14" id="tab1">



	<div class="col-md-12 text-right" style="padding-bottom:20px;">
	<a href="masterDataImportPurposeCategory.php" class="btn btn-info"><i class="fa fa-download" aria-hidden="true"></i> Import Purpose Category</a>
	
<button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal"><i class="fa fa-plus" aria-hidden="true"></i> Add Purpose</button>
	</div>


			<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Purpose</th>
                <th>Active</th>             
				<th></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Tiger Nixon</td>            
                <td><input type="checkbox"/></td>
				<td><a href="edit_customerAdmin.php" class="btn btn-info"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
<a href="#" class="btn btn-info"><i class="fa fa-trash" aria-hidden="true"></i></a>
</td>
				
            </tr>
           
        </tbody>
        <tfoot>
            <tr>
                 <th>Purpose</th>
                <th>Active</th>             
				<th></th>
            </tr>
        </tfoot>
    </table>



  
     
        </div><!-- row -->
		
		
		<div class="row tx-14" id="tab2">

		<div class="col-md-12 text-right" style="padding-bottom:20px;">
	<a href="masterDataImportExpenseCategory.php" class="btn btn-info"><i class="fa fa-download" aria-hidden="true"></i>  Import Expense Category</a>
	
<button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal2"><i class="fa fa-plus" aria-hidden="true"></i>  Add Expense Category</button>
	</div>


			<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Purpose</th>
                <th>Active</th>             
				<th></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Tiger Nixon</td>            
                <td><input type="checkbox"/></td>
				<td><a href="edit_customerAdmin.php" class="btn btn-info"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
<a href="#" class="btn btn-info"><i class="fa fa-trash" aria-hidden="true"></i></a>
</td>
				
            </tr>
           
        </tbody>
        <tfoot>
            <tr>
                 <th>Purpose</th>
                <th>Active</th>             
				<th></th>
            </tr>
        </tfoot>
    </table>

			


			

  
     
        </div><!-- row -->


<div class="row tx-14" id="tab3">
		<div class="col-md-12 text-right" style="padding-bottom:20px;">
	<a href="masterDataImportTerritoryCategory.php" class="btn btn-info"><i class="fa fa-download" aria-hidden="true"></i>  Import Territory Category</a>
	
<button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal3"><i class="fa fa-plus" aria-hidden="true"></i>  Add Territory Category</button>
	</div>


			<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Category Name</th>
                <th>Active</th>             
				<th></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Tiger Nixon</td>            
                <td><input type="checkbox"/></td>
				<td><a href="edit_customerAdmin.php" class="btn btn-info"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
<a href="#" class="btn btn-info"><i class="fa fa-trash" aria-hidden="true"></i></a>
</td>
				
            </tr>
           
        </tbody>
        <tfoot>
            <tr>
                 <th>Purpose</th>
                <th>Active</th>             
				<th></th>
            </tr>
        </tfoot>
    </table>
</div>

<div class="row tx-14" id="tab4">

<div class="col-md-12 text-right" style="padding-bottom:20px;">
	<a href="masterDataImportIndustryCategory.php" class="btn btn-info"><i class="fa fa-download" aria-hidden="true"></i>  Import Industry Category</a>
	
<button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal4"><i class="fa fa-plus" aria-hidden="true"></i>  Add Industry Category</button>
	</div>


			<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Category Name</th>
                <th>Active</th>             
				<th></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Tiger Nixon</td>            
                <td><input type="checkbox"/></td>
				<td><a href="edit_customerAdmin.php" class="btn btn-info"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
<a href="#" class="btn btn-info"><i class="fa fa-trash" aria-hidden="true"></i></a>
</td>
				
            </tr>
           
        </tbody>
        <tfoot>
            <tr>
                 <th>Purpose</th>
                <th>Active</th>             
				<th></th>
            </tr>
        </tfoot>
    </table>

</div>

<div class="row tx-14" id="tab5">
<div class="col-md-12 text-right" style="padding-bottom:20px;">

	
<button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal5"><i class="fa fa-plus" aria-hidden="true"></i>  Add Custom List</button>
	</div>


			<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>List Name</th>
                <th>Active</th>             
				<th></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Tiger Nixon</td>            
                <td><input type="checkbox"/></td>
				<td><a href="edit_customerAdmin.php" class="btn btn-info"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
<a href="#" class="btn btn-info"><i class="fa fa-trash" aria-hidden="true"></i></a>
</td>
				
            </tr>
           
        </tbody>
        <tfoot>
            <tr>
                 <th>Purpose</th>
                <th>Active</th>             
				<th></th>
            </tr>
        </tfoot>
    </table>

</div>

<div class="row tx-14" id="tab6">
<div class="col-md-12 text-right" style="padding-bottom:20px;">

	
<button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal6"><i class="fa fa-plus" aria-hidden="true"></i>  Add Office Location</button>
	</div>


			<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>List Name</th>
                <th>Active</th>             
				<th></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Tiger Nixon</td>            
                <td><input type="checkbox"/></td>
				<td><a href="edit_customerAdmin.php" class="btn btn-info"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
<a href="#" class="btn btn-info"><i class="fa fa-trash" aria-hidden="true"></i></a>
</td>
				
            </tr>
           
        </tbody>
        <tfoot>
            <tr>
                 <th>Purpose</th>
                <th>Active</th>             
				<th></th>
            </tr>
        </tfoot>
    </table>


</div>


 <!-- Add Purpose -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
         
          <h4 class="modal-title">Add Purpose Details</h4>
        </div>
        <div class="modal-body">
          <table class="table">
			<tr>
			<td>Purpose</td>
			<td><input type="text" class="form-control"/></td>
			</tr>
			<tr>
			<td>Active</td>
			<td><input type="checkbox" /></td>
			</tr>
		  
		  </table>
		  
        </div>
        <div class="modal-footer">
		    <button type="button" class="btn btn-info">Save</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
  
  
   <!-- Add expense category -->
  <div class="modal fade" id="myModal2" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
         
          <h4 class="modal-title">Add Expense Category Details</h4>
        </div>
        <div class="modal-body">
          <table class="table">
			<tr>
			<td>Category Name</td>
			<td><input type="text" class="form-control"/></td>
			</tr>
			<tr>
			<td>Active</td>
			<td><input type="checkbox" /></td>
			</tr>
		  
		  </table>
		  
        </div>
        <div class="modal-footer">
		    <button type="button" class="btn btn-info">Save</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
  
     <!-- Add Territory Category Datails -->
  <div class="modal fade" id="myModal3" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
         
          <h4 class="modal-title">Add Territory Category Details</h4>
        </div>
        <div class="modal-body">
          <table class="table">
			<tr>
			<td>Category Name</td>
			<td><input type="text" class="form-control"/></td>
			</tr>
			
			<tr>
			<td>Parent Category</td>
			<td>
			  <select class="form-control" id="sel1">
					<option>1</option>
					<option>2</option>
					
				  </select>
			</td>
			</tr>
			
			<tr>
			<td>Active</td>
			<td><input type="checkbox" /></td>
			</tr>
		  
		  </table>
		  
        </div>
        <div class="modal-footer">
		    <button type="button" class="btn btn-info">Save</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
  
  
       <!-- Add Industry Category Datails -->
  <div class="modal fade" id="myModal4" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
         
          <h4 class="modal-title">Add Insdustry Category Details</h4>
        </div>
        <div class="modal-body">
          <table class="table">
			<tr>
			<td>Category Name</td>
			<td><input type="text" class="form-control"/></td>
			</tr>
			
			
			<tr>
			<td>Active</td>
			<td><input type="checkbox" /></td>
			</tr>
		  
		  </table>
		  
        </div>
        <div class="modal-footer">
		    <button type="button" class="btn btn-info">Save</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
  
  
        <!-- Add List Details -->
  <div class="modal fade" id="myModal5" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
         
          <h4 class="modal-title">Add List Details</h4>
        </div>
        <div class="modal-body">
          <table class="table">
		  
		  	<tr>
			<td>Active</td>
			<td><input type="checkbox" /></td>
			</tr>
			
			<tr>
			<td>List Name</td>
			<td><input type="text" class="form-control"/></td>
			</tr>
			
			<tr>
			<td>List Values</td>
			<td><input type="text" class="form-control"/></td>
			</tr>
			
			
		
		  
		  </table>
		  
        </div>
        <div class="modal-footer">
		    <button type="button" class="btn btn-info">Save</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
  
          <!-- Add Office Location Details -->
  <div class="modal fade" id="myModal6" role="dialog">
    <div class="modal-dialog" style="max-width: 700px;">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
         
          <h4 class="modal-title">Add Office Location Details</h4>
        </div>
        <div class="modal-body" style="height:300px;overflow-y: scroll;">
		<div class="row">
		
		<div class="col-md-6">
		 <div class="form-group">
			<label for="email">Office Location:</label>
			<input type="text" class="form-control" id="email">
		  </div>
		  
		   <div class="form-group">
			<label for="email">Address:</label>
			<input type="text" class="form-control" id="email">
		  </div>
		  
		   <div class="form-group">
			<label for="email">City:</label>
			<input type="text" class="form-control" id="email">
		  </div>
		  
		   <div class="form-group">
			<label for="email">Zip Code:</label>
			<input type="text" class="form-control" id="email">
		  </div>
		  
		   <div class="form-group">
			<label for="email">State:</label>
			<input type="text" class="form-control" id="email">
		  </div>
		  
		   <div class="form-group">
			<label for="email">County:</label>
			<input type="text" class="form-control" id="email">
		  </div>
		  
		   <div class="form-group">
			<label for="email">Actice:</label>
			<input type="checkbox" id="email">
		  </div>
		
		</div>
		<div class="col-md-6">
		<div class="mapouter"><div class="gmap_canvas"><iframe width="100%" height="280" id="gmap_canvas" src="https://maps.google.com/maps?q=university%20of%20san%20francisco&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><a href="https://www.crocothemes.net">wordpress themes;</a></div><style>.mapouter{position:relative;text-align:right;height:280px;width:100%;}.gmap_canvas {overflow:hidden;background:none!important;height:280px;width:100%;}</style></div>
		</div>
		  
		</div>
        </div>
        <div class="modal-footer">
		    <button type="button" class="btn btn-info">Save</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
     <?php

include "include/footer.php";
?>

    
    </div><!-- content -->

    <script src="lib/jquery/jquery.min.js"></script>
    <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="lib/feather-icons/feather.min.js"></script>
    <script src="lib/perfect-scrollbar/perfect-scrollbar.min.js"></script>

	 <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>

    <script src="assets/js/dashforge.js"></script>
    <script>
      $(function(){
        'use strict'

      });
    </script>

	<script>
$(document).ready(function() {
    $('#example').DataTable();
} );
</script>


<script>
$(document).ready(function(){
$('#tab1').addClass('show');
$('#tab2').addClass('hide');
$('#tab3').addClass('hide');
$('#tab4').addClass('hide');
$('#tab5').addClass('hide');
$('#tab6').addClass('hide');
$('#btn1').click(function(){
$('#tab1').removeClass('hide');
$('#tab2').addClass('hide');
$('#tab3').addClass('hide');
$('#tab4').addClass('hide');
$('#tab5').addClass('hide');
$('#tab6').addClass('hide');
});

$('#btn2').click(function(){
$('#tab2').removeClass('hide');
$('#tab1').addClass('hide');
$('#tab3').addClass('hide');
$('#tab4').addClass('hide');
$('#tab5').addClass('hide');
$('#tab6').addClass('hide');
});

$('#btn3').click(function(){
$('#tab2').addClass('hide');
$('#tab1').addClass('hide');
$('#tab3').removeClass('hide');
$('#tab4').addClass('hide');
$('#tab5').addClass('hide');
$('#tab6').addClass('hide');
});

$('#btn4').click(function(){
$('#tab2').addClass('hide');
$('#tab1').addClass('hide');
$('#tab3').addClass('hide');
$('#tab4').removeClass('hide');
$('#tab5').addClass('hide');
$('#tab6').addClass('hide');
});

$('#btn5').click(function(){
$('#tab2').addClass('hide');
$('#tab1').addClass('hide');
$('#tab3').addClass('hide');
$('#tab4').addClass('hide');
$('#tab5').removeClass('hide');
$('#tab6').addClass('hide');
});

$('#btn6').click(function(){
$('#tab2').addClass('hide');
$('#tab1').addClass('hide');
$('#tab3').addClass('hide');
$('#tab4').addClass('hide');
$('#tab5').addClass('hide');
$('#tab6').removeClass('hide');
});

});
</script>


  </body>
</html>

