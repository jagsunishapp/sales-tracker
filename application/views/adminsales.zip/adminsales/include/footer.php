   <footer class="content-footer">
          <div>
            <span>&copy; 2019 IndianSmarthub</span>
           
          </div>
   
        </footer><!-- content-footer -->