<?php

include "include/header.php";
?>

    <div id="sidebarMenu" class="sidebar sidebar-fixed sidebar-components">
      <div class="sidebar-header">
        <a href="" id="mainMenuOpen"><i data-feather="menu"></i></a>
        <h5>Components</h5>
        <a href="" id="sidebarMenuClose"><i data-feather="x"></i></a>
      </div><!-- sidebar-header -->
      <div class="sidebar-body">
        <ul class="sidebar-nav">
         <li class="nav-label mg-b-15">Master</li>
		 <li class="nav-item"><a href="#" class="btn btn-info" id="btn1"> <i class="fa fa-pencil-square-o" aria-hidden="true"></i> Create From</a></li>
         <li class="nav-item"><a href="#" id="btn2"> Customer Bio Data</a></li>

		<li class="nav-item"><a href="#" id="btn3"> Test</a></li>
		<li class="nav-item"><a href="#" id="btn4">Visiting Form</a></li>
		
		
         
	
          
         
         
        </ul>
      </div><!-- sidebar-body -->
    </div><!-- sidebar -->

    <div class="content content-components">
   
   

 
        <div class="row tx-14" id="tab1">
			<h2>Form Details</h2>
			
			<form>
		<div class="form-group">
			<label for="email">Form name:</label>
			<input type="text" class="form-control" id="email">
		 </div>
		 
		 <div class="form-group">
			<label for="email">Active:</label>
			<input type="checkbox" >
		 </div>
		 
		 <div class="form-group">
			<label for="email">Related To:</label>
			 <select class="form-control" id="sel1">
				<option>1</option>
				<option>2</option>
				<option>3</option>
				<option>4</option>
			  </select>
		 </div>
		 
		 <div class="form-group">
			<label for="email">When to be filled by user:</label>
			 <select class="form-control" id="sel1">
				<option>1</option>
				<option>2</option>
				<option>3</option>
				<option>4</option>
			  </select>
		 </div>
		 
		 <div class="form-group">
			<label for="email">Submit Button Caption:</label>
			<input type="text" class="form-control" id="email">
		 </div>
		 
		 <div class="form-group">
			<label for="email">Mobile only:</label>
			<input type="checkbox" >
		 </div>
		 
		
		
			
			</form>
		<div class="row" style="padding:10px 0px;">
		<div class="col-md-12 text-right">
		<button class="btn btn-info"><i class="fa fa-plus" aria-hidden="true"></i> Add Components</button>
		</div>
			</div>
		 <table class="table">
    <thead>
      <tr>
        <th>#</th>
        <th>Label</th>
        <th>Type</th>
		<th>mandatory</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>John</td>
        <td>Doe</td>
        <td>john@example.com</td>
		<td>john@example.com</td>
      </tr>
 
    </tbody>
  </table>
  
  <div class="row" style="padding:20px 0px;">
  <div class="col-md-12">
	<button class="btn btn-info">Save</button>
	<button class="btn btn-default">Reset</button>
	<button class="btn btn-default">Preview</button>
  </div>
  </div>
  
        </div><!-- row -->
		
		  <div class="row tx-14" id="tab2">
	<h2>Form Details</h2>
	<div class="col-md-12">
	<form>
		<div class="form-group">
			<label for="email">Form name:</label>
			<input type="text" class="form-control" id="email">
		 </div>
		 
		 <div class="form-group">
			<label for="email">Active:</label>
			<input type="checkbox" >
		 </div>
		 
		 <div class="form-group">
			<label for="email">Related To:</label>
			 <select class="form-control" id="sel1">
				<option>1</option>
				<option>2</option>
				<option>3</option>
				<option>4</option>
			  </select>
		 </div>
		 
		 <div class="form-group">
			<label for="email">When to be filled by user:</label>
			 <select class="form-control" id="sel1">
				<option>1</option>
				<option>2</option>
				<option>3</option>
				<option>4</option>
			  </select>
		 </div>
		 
		 <div class="form-group">
			<label for="email">Submit Button Caption:</label>
			<input type="text" class="form-control" id="email">
		 </div>
		 
		 <div class="form-group">
			<label for="email">Mobile only:</label>
			<input type="checkbox" >
		 </div>
		 
		
		
			
			</form>
			</div>
			
				<div class="col-md-12 text-right" style="padding:10px 0px;">
		<button class="btn btn-info"><i class="fa fa-plus" aria-hidden="true"></i> Add Components</button>
		</div>
		
		<div class="col-md-12">
		
			 <table class="table">
    <thead>
      <tr>
        <th>#</th>
        <th>Label</th>
        <th>Type</th>
		<th>mandatory</th>
		<th></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>John</td>
        <td>Doe</td>
        <td>john@example.com</td>
		<td>john@example.com</td>
		<td><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal2"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button></td>
      </tr>
 
    </tbody>
  </table>
		
		
		</div>
		
		  <div class="col-md-12">
	<button class="btn btn-info">Save</button>
	<button class="btn btn-default">Reset</button>
	<button class="btn btn-default">Preview</button>
  </div>
  
        </div><!-- row -->
		
		
		  <div class="row tx-14" id="tab3">
			<h2>Form Details</h2>
	<div class="col-md-12">
	<form>
		<div class="form-group">
			<label for="email">Form name:</label>
			<input type="text" class="form-control" id="email">
		 </div>
		 
		 <div class="form-group">
			<label for="email">Active:</label>
			<input type="checkbox" >
		 </div>
		 
		 <div class="form-group">
			<label for="email">Related To:</label>
			 <select class="form-control" id="sel1">
				<option>1</option>
				<option>2</option>
				<option>3</option>
				<option>4</option>
			  </select>
		 </div>
		 
		 <div class="form-group">
			<label for="email">When to be filled by user:</label>
			 <select class="form-control" id="sel1">
				<option>1</option>
				<option>2</option>
				<option>3</option>
				<option>4</option>
			  </select>
		 </div>
		 
		 <div class="form-group">
			<label for="email">Submit Button Caption:</label>
			<input type="text" class="form-control" id="email">
		 </div>
		 
		 <div class="form-group">
			<label for="email">Mobile only:</label>
			<input type="checkbox" >
		 </div>
		 
		
		
			
			</form>
			</div>
			
				<div class="col-md-12 text-right" style="padding:10px 0px;">
		<button class="btn btn-info"><i class="fa fa-plus" aria-hidden="true"></i> Add Components</button>
		</div>
		
		<div class="col-md-12">
		
			 <table class="table">
    <thead>
      <tr>
        <th>#</th>
        <th>Label</th>
        <th>Type</th>
		<th>mandatory</th>
		<th></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>John</td>
        <td>Doe</td>
        <td>john@example.com</td>
		<td>john@example.com</td>
		<td><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button></td>
      </tr>
 
    </tbody>
  </table>
		
		
		</div>
		
		  <div class="col-md-12">
	<button class="btn btn-info">Save</button>
	<button class="btn btn-default">Reset</button>
	<button class="btn btn-default">Preview</button>
  </div>
        </div><!-- row -->
		
		  <div class="row tx-14" id="tab4">
			
					<h2>Form Details</h2>
	<div class="col-md-12">
	<form>
		<div class="form-group">
			<label for="email">Form name:</label>
			<input type="text" class="form-control" id="email">
		 </div>
		 
		 <div class="form-group">
			<label for="email">Active:</label>
			<input type="checkbox" >
		 </div>
		 
		 <div class="form-group">
			<label for="email">Related To:</label>
			 <select class="form-control" id="sel1">
				<option>1</option>
				<option>2</option>
				<option>3</option>
				<option>4</option>
			  </select>
		 </div>
		 
		 <div class="form-group">
			<label for="email">When to be filled by user:</label>
			 <select class="form-control" id="sel1">
				<option>1</option>
				<option>2</option>
				<option>3</option>
				<option>4</option>
			  </select>
		 </div>
		 
		 <div class="form-group">
			<label for="email">Submit Button Caption:</label>
			<input type="text" class="form-control" id="email">
		 </div>
		 
		 <div class="form-group">
			<label for="email">Mobile only:</label>
			<input type="checkbox" >
		 </div>
		 
		
		
			
			</form>
			</div>
			
				<div class="col-md-12 text-right" style="padding:10px 0px;">
		<button class="btn btn-info"><i class="fa fa-plus" aria-hidden="true"></i> Add Components</button>
		</div>
		
		<div class="col-md-12">
		
			 <table class="table">
    <thead>
      <tr>
        <th>#</th>
        <th>Label</th>
        <th>Type</th>
		<th>mandatory</th>
		<th></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>John</td>
        <td>Doe</td>
        <td>john@example.com</td>
		<td>john@example.com</td>
		<td><button type="button" class="btn btn-info btn-lg" data-toggle="modal3" data-target="#myModal3"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button></td>
      </tr>
 
    </tbody>
  </table>
		
		
		</div>
		
		  <div class="col-md-12">
	<button class="btn btn-info">Save</button>
	<button class="btn btn-default">Reset</button>
	<button class="btn btn-default">Preview</button>
  </div>
  
        </div><!-- row -->


<!-- Customerbio Data-->
 <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
         
          <h4 class="modal-title">Add Component</h4>
        </div>
        <div class="modal-body">
		
		
          <div class="form-group">
			<label for="email">Label:</label>
			<input type="text" class="form-control" id="email">
		  </div>
		  
		    <div class="form-group">
			<label for="email">Type:</label>
			 <select class="form-control" id="sel1">
				<option>1</option>
				<option>2</option>

			  </select>
		  </div>
		  
		    <div class="form-group">
			<label for="email">Placeholder:</label>
			<input type="text" class="form-control" id="email">
		  </div>
		  
		  <div class="form-group">
			<label for="">Mandatory</label><br>
			<label class="radio-inline"><input type="radio" name="optradio" checked> Yes</label>&nbsp;&nbsp;
			<label class="radio-inline"><input type="radio" name="optradio"> No</label>
		  </div>
		  
		  <div class="form-group">
			<label for="">Editable</label><br>
			<label class="radio-inline"><input type="radio" name="optradio" checked> Yes</label>&nbsp;&nbsp;
			<label class="radio-inline"><input type="radio" name="optradio"> No</label>
		  </div>
		  
        </div>
        <div class="modal-footer">
		  <button type="button" class="btn btn-info" data-dismiss="modal">Save</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
  
  
  <!-- test-->
 <div class="modal fade" id="myModal2" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
         
          <h4 class="modal-title">Add Component</h4>
        </div>
        <div class="modal-body">
		
		
          <div class="form-group">
			<label for="email">Label:</label>
			<input type="text" class="form-control" id="email">
		  </div>
		  
		    <div class="form-group">
			<label for="email">Type:</label>
			 <select class="form-control" id="sel1">
				<option>1</option>
				<option>2</option>

			  </select>
		  </div>
		  
		    <div class="form-group">
			<label for="email">Placeholder:</label>
			<input type="text" class="form-control" id="email">
		  </div>
		  
		  <div class="form-group">
			<label for="">Mandatory</label><br>
			<label class="radio-inline"><input type="radio" name="optradio" checked> Yes</label>&nbsp;&nbsp;
			<label class="radio-inline"><input type="radio" name="optradio"> No</label>
		  </div>
		  
		  <div class="form-group">
			<label for="">Editable</label><br>
			<label class="radio-inline"><input type="radio" name="optradio" checked> Yes</label>&nbsp;&nbsp;
			<label class="radio-inline"><input type="radio" name="optradio"> No</label>
		  </div>
		  
        </div>
        <div class="modal-footer">
		  <button type="button" class="btn btn-info" data-dismiss="modal">Save</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
  
  
    <!-- Visiting Form-->
 <div class="modal fade" id="myModal3" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
         
          <h4 class="modal-title">Add Component 3</h4>
        </div>
        <div class="modal-body">
		
		
          <div class="form-group">
			<label for="email">Label:</label>
			<input type="text" class="form-control" id="email">
		  </div>
		  
		    <div class="form-group">
			<label for="email">Type:</label>
			 <select class="form-control" id="sel1">
				<option>1</option>
				<option>2</option>

			  </select>
		  </div>
		  
		    <div class="form-group">
			<label for="email">Placeholder:</label>
			<input type="text" class="form-control" id="email">
		  </div>
		  
		  <div class="form-group">
			<label for="">Mandatory</label><br>
			<label class="radio-inline"><input type="radio" name="optradio" checked> Yes</label>&nbsp;&nbsp;
			<label class="radio-inline"><input type="radio" name="optradio"> No</label>
		  </div>
		  
		  <div class="form-group">
			<label for="">Editable</label><br>
			<label class="radio-inline"><input type="radio" name="optradio" checked> Yes</label>&nbsp;&nbsp;
			<label class="radio-inline"><input type="radio" name="optradio"> No</label>
		  </div>
		  
        </div>
        <div class="modal-footer">
		  <button type="button" class="btn btn-info" data-dismiss="modal">Save</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
     <?php

include "include/footer.php";
?>

    
    </div><!-- content -->

    <script src="lib/jquery/jquery.min.js"></script>
    <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="lib/feather-icons/feather.min.js"></script>
    <script src="lib/perfect-scrollbar/perfect-scrollbar.min.js"></script>

	 <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>

    <script src="assets/js/dashforge.js"></script>
    <script>
      $(function(){
        'use strict'

      });
    </script>

	<script>
$(document).ready(function() {
    $('#example').DataTable();
} );
</script>

<script>
$(document).ready(function(){
$('#tab1').addClass('show');
$('#tab2').addClass('hide');
$('#tab3').addClass('hide');
$('#tab4').addClass('hide');
$('#tab5').addClass('hide');
$('#tab6').addClass('hide');
$('#btn1').click(function(){
$('#tab1').removeClass('hide');
$('#tab2').addClass('hide');
$('#tab3').addClass('hide');
$('#tab4').addClass('hide');
$('#tab5').addClass('hide');
$('#tab6').addClass('hide');
});

$('#btn2').click(function(){
$('#tab2').removeClass('hide');
$('#tab1').addClass('hide');
$('#tab3').addClass('hide');
$('#tab4').addClass('hide');
$('#tab5').addClass('hide');
$('#tab6').addClass('hide');
});

$('#btn3').click(function(){
$('#tab2').addClass('hide');
$('#tab1').addClass('hide');
$('#tab3').removeClass('hide');
$('#tab4').addClass('hide');
$('#tab5').addClass('hide');
$('#tab6').addClass('hide');
});

$('#btn4').click(function(){
$('#tab2').addClass('hide');
$('#tab1').addClass('hide');
$('#tab3').addClass('hide');
$('#tab4').removeClass('hide');
$('#tab5').addClass('hide');
$('#tab6').addClass('hide');
});

$('#btn5').click(function(){
$('#tab2').addClass('hide');
$('#tab1').addClass('hide');
$('#tab3').addClass('hide');
$('#tab4').addClass('hide');
$('#tab5').removeClass('hide');
$('#tab6').addClass('hide');
});

$('#btn6').click(function(){
$('#tab2').addClass('hide');
$('#tab1').addClass('hide');
$('#tab3').addClass('hide');
$('#tab4').addClass('hide');
$('#tab5').addClass('hide');
$('#tab6').removeClass('hide');
});

});
</script>


  </body>
</html>

